import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_cubit_changetheme/views/change_theme/view.dart';

import 'features/change_theme/cubit.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (BuildContext context) => ChangeThemesCubit(),
      child: BlocBuilder<ChangeThemesCubit,ThemesStates>(
        builder: (context, state) {
          return MaterialApp(
            title: 'Change Themes',
            debugShowCheckedModeBanner: false,
            theme: ThemeData(
              brightness: Brightness.light,
              scaffoldBackgroundColor: Colors.white,
              colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
              appBarTheme: AppBarTheme(
                  titleTextStyle: TextStyle(color: Colors.black,fontSize: 21,fontWeight: FontWeight.w600),
                  centerTitle: true
              ),
              useMaterial3: true,
            ),
            darkTheme: ThemeData(
              brightness: Brightness.dark,
              scaffoldBackgroundColor: Colors.black,
              appBarTheme: AppBarTheme(
                  titleTextStyle: TextStyle(color: Colors.white,fontSize: 21,fontWeight: FontWeight.w600),
                  centerTitle: true
              ),
            ),
            themeMode: state is DarkThemeState?ThemeMode.dark:ThemeMode.light,
            home: const ChangeThemeView(),
          );
        },
      ),
    );
  }
}


