part of 'cubit.dart';

class ThemesStates{}

class LightThemeState extends ThemesStates{}

class DarkThemeState extends ThemesStates{}